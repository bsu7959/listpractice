package com.koreait.board;

import java.util.*;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.koreait.db.SqlMapConfigBoard;


public class BoardDAO {
	
	SqlSessionFactory ssf = SqlMapConfigBoard.getSqlMapInstance();
	SqlSession sqlsession;
	List<BoardDTO> boardList = new ArrayList<>();
	public BoardDAO() {
		sqlsession = ssf.openSession(true);	// openSessioni(true) 설정시 자동 commit
		System.out.println("마이바티스 설정 성공");
	}
	
	public int upload(BoardDTO board) {
		HashMap<String, String> dataMap = new HashMap<>();

		dataMap.put("b_userid", board.getB_userid());
		dataMap.put("b_name", board.getB_name());
		dataMap.put("b_title", board.getB_title());
		dataMap.put("b_content", board.getB_content());
		
		return sqlsession.insert("Board.upload", dataMap);
	}
	
	public int count() {
		
		return sqlsession.selectOne("Board.totalCount");
	}
	
	public List<BoardDTO> selectList(int pagePerCount, int start) {
		
		HashMap<String, Integer> dataMap = new HashMap<>();
		dataMap.put("pagePerCount", pagePerCount);
		dataMap.put("start", start);
		System.out.println(pagePerCount + " " + start);
		boardList = sqlsession.selectList("Board.selectList", dataMap);
		System.out.println(boardList.size());
		return boardList;
	}
}
